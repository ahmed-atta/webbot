 <!-- Static navbar -->
      <div class="navbar navbar-default" role="navigation">
        <div class="navbar-collapse collapse">
          <ul class="nav navbar-nav navbar-right">
			
			<li><a href="settings.php"> الإعدادات</a></li>
		    <li><a href="search.php"> البحث - الجوال</a></li>
			<li><a href="ads.php">إعلانات حراج/مستعمل</a></li>
            <li><a href="haraj.php">حراج </a></li>
            <li><a href="mstaml.php">مستعمل </a></li>
			<li class="active"><a href="./">الرئيسية </a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>