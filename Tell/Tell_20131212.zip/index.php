<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="http://netdna.bootstrapcdn.com/bootstrap/3.0.3/css/bootstrap.min.css">
<!-- Optional theme -->
<link rel="stylesheet" href="http://netdna.bootstrapcdn.com/bootstrap/3.0.3/css/bootstrap-theme.min.css">
<!-- Latest compiled and minified JavaScript -->
<script src="http://netdna.bootstrapcdn.com/bootstrap/3.0.3/js/bootstrap.min.js"></script>
<style>
</style>
</head>
<body>
    <div class="container">

      <!-- Static navbar -->
      <div class="navbar navbar-default" role="navigation">
        <div class="navbar-collapse collapse">
          <ul class="nav navbar-nav navbar-right">
            <li><a href="haraj.php">حراج </a></li>
            <li><a href="mstaml.php">مستعمل </a></li>
			 <li class="active"><a href="./">الرئيسية </a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>

      <!-- Main component for a primary marketing message or call to action -->
      <div class="jumbotron">
		<form class="form-inline" role="form" method="POST" action="">
		  <div class="form-group">
			<input  type="text" name="from" class="form-control" id="exampleInputEmail2" placeholder="From: 2013-09-01">
		  </div>
		  <div class="form-group"> 
			<input type="text" class="form-control" id="exampleInputPassword2" name="to" placeholder="To: 2013-09-21">
		  </div>
		  <div class="checkbox">
			<label> 
			  <input type="checkbox" name="All" value="YES">  All  &nbsp;&nbsp;&nbsp;
			</label>
		  </div>
		  <input type="hidden" class="form-control" id="exampleInputPassword2" name="submit" value="set">
		  <button type="submit" class="btn btn-default"  >  &nbsp;&nbsp GO  &nbsp;&nbsp </button>
		</form>
		<!-- =============================== -->
        <?php $rows ='';
		if(isset($_POST['submit'])){
			require_once("config.php");
			if(isset($_POST["All"]) && $_POST["All"] == "YES") {
						$result =$mysqli->query("SELECT * FROM `phones`") or die(mysql_error());
					if (mysqli_num_rows($result) > 0 ) {
							
							while($row = $result->fetch_row()){
								$rows.= strip_tags($row[1]).",";
							}
					} else 
						$rows .="NO RESULTS";
			}else {
				$from = $_POST['from'];
				$to = $_POST['to'];
				$result =$mysqli->query("SELECT * FROM `phones` WHERE created > '$from' AND created < '$to'") or die(mysql_error());
				if (mysqli_num_rows($result) > 0 ) {
							
							while($row = $result->fetch_row()){
								$rows.= strip_tags($row[1]).",";
							}
				} else 
						$rows .="NO RESULTS";	 
				
			}
		}	
			
		?>
		<textarea class="form-control" rows="20"><?php echo $rows; ?></textarea>
		
      </div>

    </div> <!-- /container -->


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>


</body>
</html>
