<?php

require_once("config.php");
if(isset($_POST['start']) && isset($_POST['end'])){
	$start = (int)$_POST['start'];
	$end = (int) $_POST['end'];
	for($i = $start; $i<= $end; $i++ ){
		$contents = @file_get_contents("http://haraj.com.sa/".$i);
		@preg_match('/<span class="red">(.*)<\/span>/i', $contents, $matches); // 0551016333
		//echo "<xmp>".@$matches[0]."</xmp>";
		//echo "<xmp>".@$matches[1]."</xmp>";
		 //echo $key."<br/>";
		 if(!empty($matches[1]) && strlen($matches[1]) > 5 ){
			$number = getNumber($matches[1]);
			if(!empty($number))
				InsertData($mysqli,$number,"haraj");
		}
	}
	$msg = "Processing finished ..................";
}

# Extract the number from a date string 
//
//preg_match($pattern, $contents, $matches, PREG_OFFSET_CAPTURE);
//echo  mb_convert_encoding( $output , 'HTML-ENTITIES', "UTF-8");

//$xml = new DOMDocument();
//$xml->loadXML( $contents );


//==============================================
function curl_get_file_contents($URL){
        $c = curl_init();
        curl_setopt($c, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($c, CURLOPT_URL, $URL);
        $contents = curl_exec($c);
        curl_close($c);

        if ($contents) return $contents;
            else return FALSE;
    }
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="http://netdna.bootstrapcdn.com/bootstrap/3.0.3/css/bootstrap.min.css">
<!-- Optional theme -->
<link rel="stylesheet" href="http://netdna.bootstrapcdn.com/bootstrap/3.0.3/css/bootstrap-theme.min.css">
<!-- Latest compiled and minified JavaScript -->
<script src="http://netdna.bootstrapcdn.com/bootstrap/3.0.3/js/bootstrap.min.js"></script>
<style>
.jumbotron{
margin-top: 20px;
}
.col-sm-10 {
	width:20%;
	padding:0px;
}
.col-sm-2 {
width:40%;
font-size:15px;
padding:0px;
}
</style>
</head>
<body>

<div class="container">
<!-- Static navbar -->
      <div class="navbar navbar-default" role="navigation">
        <div class="navbar-header">
          <a class="navbar-brand" href="#"></a>
        </div>
        <div class="navbar-collapse collapse">
          <ul class="nav navbar-nav navbar-right">
            <li class="active"><a href="haraj.php">حراج </a></li>
            <li><a href="mstaml.php">مستعمل </a></li>
			 <li><a href="./">الرئيسية </a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>

 <div class="jumbotron">
 <?php  if(isset($msg)) echo "<h3 style='text-align:center;color:red'>".$msg."</h3>"; ?>
<form class="form-horizontal" role="form" action="" method="POST">
<div class="form-group">
    <label class="col-sm-2 control-label"></label>
    <div class="col-sm-10">
      <p class="form-control-static">Start</p>
    </div>
</div>
  <div class="form-group">
    <label for="inputPassword" class="col-sm-2 control-label">http://haraj.com.sa/</label>
    <div class="col-sm-10">
      <input type="text" name="start" class="form-control" id="inputPassword" placeholder="00">
    </div>
  </div>
  
 <div class="form-group">
    <label class="col-sm-2 control-label"></label>
    <div class="col-sm-10">
      <p class="form-control-static">End</p>
    </div>
</div>
  <div class="form-group">
    <label for="inputPassword" class="col-sm-2 control-label">http://haraj.com.sa/</label>
    <div class="col-sm-10">
      <input type="text" name="end" class="form-control" id="inputPassword" placeholder="1711442">
    </div>
  </div>
  
	<button type="submit" class="btn btn-default">Submit</button>
	
</form>

...</div>
</div>

</body>
</html>
