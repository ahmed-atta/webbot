﻿<?php
require_once("config.php");
if(isset($_POST['start']) && isset($_POST['end'])){

	$start = (int)$_POST['start'];
	$end = (int) $_POST['end'];
	
	for($i = $start; $i<= $end; $i++ ){
		$contents = @file_get_contents("http://www.mstaml.com/section/item.php?i=".$i,FILE_TEXT,$context);
		@preg_match('/userInfo(.*)(;)/i', $contents, $matches);
		@preg_match('/<b>القسم<\/b>(.*)<\/a>/i', $contents, $category); // Category 
		@preg_match('/<b>المكان<\/b>(.*)<\/a>/i', $contents, $city); // City
		
		$categ = @mb_convert_encoding($category[1], 'UTF-8',mb_detect_encoding($category[1], 'UTF-8, ISO-8859-1', true));
		$city_c = @mb_convert_encoding($city[1], 'UTF-8',mb_detect_encoding($city[1], 'UTF-8, ISO-8859-1', true));
		$categ  = @strip_tags($categ); // echo  "<xmp>".$categ."</xmp>";
		$city_c  = @strip_tags($city_c); // echo  "<xmp>".$categ."</xmp>";
	
		//============================================//
		$data =  @explode(",",$matches[0]);
		$mobile = @explode(":",$data[1]);
		$phone =  @explode(":",$data[2]);
		$other = @explode(":",$data[3]);
		
		
		$m = @trim(str_replace('"', " ", $mobile[1]));
		$p = @trim(str_replace('"', " ", $phone[1]));
		$o = @trim(str_replace('"', " ",rtrim( $other[1],"};")));

		 $Tels = array();
		if(!empty($m) && strlen($m) > 5){
			 $Tels[$m] = 1;
		}
		if(!empty($p) && strlen($p) > 5 ){
			 $Tels[$p] = 1 ;
		}
		if(!empty($o) && strlen($o) > 5 ){
			 $Tels[$o] = 1;
		}
		
		foreach( $Tels as $key=>$value){
		    //echo $key."<br/>";
			$number = getNumber($key);
			$querystring = $start." - ".$i." - ".$end;
			if(!empty($number))
				InsertData($mysqli,$number,"mstaml",$querystring,$categ,$city_c);
		}
	}
	$msg = "Processing finished ..................";
}


//==================== Last Process ========================== //
$result = $mysqli->query("SELECT querystring FROM `phones` WHERE site = 'mstaml' ORDER BY id DESC LIMIT 1;");
    if (mysqli_num_rows($result) > 0 ) {  
		$row = $result->fetch_assoc();
		$qs = $row['querystring'];
		$se = explode('-',$qs);
		$lstart = $se[0];
		$lend = $se[1];
		$fend = $se[2];
	}
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="http://netdna.bootstrapcdn.com/bootstrap/3.0.3/css/bootstrap.min.css">
<!-- Optional theme -->
<link rel="stylesheet" href="http://netdna.bootstrapcdn.com/bootstrap/3.0.3/css/bootstrap-theme.min.css">
<!-- Latest compiled and minified JavaScript -->
<script src="http://netdna.bootstrapcdn.com/bootstrap/3.0.3/js/bootstrap.min.js"></script>
<style>
.jumbotron{
margin-top: 20px;
}
.col-sm-10 {
	width:20%;
	padding:0px;
}
.col-sm-2 {
width:40%;
font-size:15px;
padding:0px;
}
</style>
</head>
<body>

<div class="container">
 <!-- Static navbar -->
      <div class="navbar navbar-default" role="navigation">
        <div class="navbar-header">
          <a class="navbar-brand" href="#"></a>
        </div>
        <div class="navbar-collapse collapse">
          <ul class="nav navbar-nav navbar-right">
            <li><a href="haraj.php">حراج </a></li>
            <li class="active"><a href="mstaml.php">مستعمل </a></li>
			 <li ><a href="./">الرئيسية </a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>

 <div class="jumbotron">
 <?php  if(isset($msg)) echo "<h3 style='text-align:center;color:red'>".$msg."</h3>"; ?>
 
<form class="form-horizontal" role="form" action="" method="POST">
<div class="form-group">
    <label class="col-sm-2 control-label"></label>
    <div class="col-sm-10">
      <p class="form-control-static">Start</p>
    </div>
</div>
  <div class="form-group">
    <label for="inputPassword" class="col-sm-2 control-label">http://www.mstaml.com/section/item.php?i=</label>
    <div class="col-sm-10">
      <input type="text" name="start" class="form-control" id="inputPassword" placeholder="<?php echo (isset($lstart))? $lstart : '';?>">
    </div>
  </div>
  
 <div class="form-group">
    <label class="col-sm-2 control-label"></label>
    <div class="col-sm-10">
      <p class="form-control-static">End</p>
    </div>
</div>
  <div class="form-group">
    <label for="inputPassword" class="col-sm-2 control-label">http://www.mstaml.com/section/item.php?i=</label>
    <div class="col-sm-10"> 
      <input type="text" name="end" class="form-control" id="inputPassword" placeholder="<?php echo (isset($fend))? $fend : '';?>">
	  <span class="label label-success"><?php echo (isset($lend))? $lend : '';?></span>
    </div>
  </div>
  
	<button type="submit" class="btn btn-default">Submit</button>
	
</form>

</div>
</div>

</body>
</html>
